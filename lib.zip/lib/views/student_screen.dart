import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utils/app_theme.dart';

class StudentScreen extends StatefulWidget {
  final String studentName;
  final int    studentId;
  final String? rollNo;
  const StudentScreen({
    super.key,
    this.studentName = 'Student',
    this.studentId = 0,
    this.rollNo,
  });
  @override
  State<StudentScreen> createState() => _StudentScreenState();
}

class _StudentScreenState extends State<StudentScreen> {
  int _tab = 0;

  String get _initials {
    final p = widget.studentName.trim().split(' ');
    if (p.length >= 2) return '${p[0][0]}${p[1][0]}'.toUpperCase();
    return widget.studentName.isNotEmpty
        ? widget.studentName[0].toUpperCase()
        : 'S';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          _buildAppBar(),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
              children: [
                _SummaryCard(studentName: widget.studentName),
                const SizedBox(height: 20),
                const _SectionTitle('Quick Actions'),
                const SizedBox(height: 10),
                _QuickActions(),
                const SizedBox(height: 22),
                const _SectionTitle('Upcoming Exams'),
                const SizedBox(height: 10),
                ..._upcomingExams(),
                const SizedBox(height: 22),
                const _SectionTitle('Recent Activity'),
                const SizedBox(height: 10),
                _RecentActivity(),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: _BottomNav(
        selected: _tab,
        onTap: (i) {
          setState(() => _tab = i);
          HapticFeedback.selectionClick();
        },
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          bottom: BorderSide(color: AppTheme.divider, width: 1),
        ),
        boxShadow: [
          BoxShadow(
              color: Color(0x05000000),
              blurRadius: 8,
              offset: Offset(0, 2)),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  gradient: AppTheme.primaryGrad,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    _initials,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.studentName,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.text1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    if (widget.rollNo != null)
                      Text(
                        'Roll No: ${widget.rollNo}',
                        style: const TextStyle(
                            fontSize: 12, color: AppTheme.text3),
                      ),
                  ],
                ),
              ),
              _AppBarAction(
                icon: Icons.notifications_outlined,
                onTap: () {},
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _upcomingExams() {
    final exams = [
      ('Flutter Development', 'Mar 22  ·  10:00 AM', AppTheme.primary),
      ('Data Structures', 'Mar 25  ·  2:00 PM', AppTheme.green),
      ('C++ Programming', 'Mar 28  ·  9:00 AM', AppTheme.violet),
    ];
    return exams
        .map((e) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ExamTile(
                  subject: e.$1, time: e.$2, color: e.$3),
            ))
        .toList();
  }
}

// ── App Bar Action ─────────────────────────
class _AppBarAction extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _AppBarAction({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(
          color: AppTheme.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.border, width: 1.2),
        ),
        child: Icon(icon, size: 20, color: AppTheme.text2),
      ),
    );
  }
}

// ── Summary Card ──────────────────────────
class _SummaryCard extends StatelessWidget {
  final String studentName;
  const _SummaryCard({required this.studentName});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.heroGrad,
        borderRadius: BorderRadius.circular(20),
        boxShadow: AppTheme.glowShadow(AppTheme.primary),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Hello, ${studentName.split(' ')[0]} 👋',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 3),
                    const Text(
                      'Semester Progress',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: -0.3,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(50),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.star_rounded,
                        size: 14, color: Colors.white),
                    SizedBox(width: 4),
                    Text(
                      'GPA 3.8',
                      style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.white),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Expanded(
                child: Text(
                  '78% Completed',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white70,
                  ),
                ),
              ),
              const Text(
                '78%',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: 0.78,
              minHeight: 6,
              backgroundColor: Colors.white.withOpacity(0.22),
              valueColor:
                  const AlwaysStoppedAnimation(Colors.white),
            ),
          ),
          const SizedBox(height: 18),
          Row(
            children: const [
              _MiniStat('12', 'Exams Done'),
              SizedBox(width: 24),
              _MiniStat('84%', 'Avg Score'),
              SizedBox(width: 24),
              _MiniStat('3', 'Upcoming'),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String value, label;
  const _MiniStat(this.value, this.label);

  @override
  Widget build(BuildContext context) =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(value,
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Colors.white)),
        Text(label,
            style: const TextStyle(
                fontSize: 11, color: Colors.white60)),
      ]);
}

// ── Quick Actions ─────────────────────────
class _QuickActions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.edit_note_rounded,      'Take Exam',    AppTheme.primary, AppTheme.primaryBg),
      (Icons.bar_chart_rounded,      'My Results',   AppTheme.green,   AppTheme.greenBg),
      (Icons.calendar_month_rounded, 'Schedule',     AppTheme.violet,  AppTheme.violetBg),
      (Icons.folder_open_rounded,    'Materials',    AppTheme.amber,   AppTheme.amberBg),
    ];
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 8,
      crossAxisSpacing: 8,
      childAspectRatio: 3.0,
      children: items
          .map((a) => GestureDetector(
                onTap: () => HapticFeedback.lightImpact(),
                child: Container(
                  decoration: AppTheme.card(
                      borderColor: a.$3.withOpacity(0.18)),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      Container(
                        width: 30,
                        height: 30,
                        decoration: BoxDecoration(
                          color: a.$4,
                          borderRadius:
                              BorderRadius.circular(8),
                        ),
                        child:
                            Icon(a.$1, size: 15, color: a.$3),
                      ),
                      const SizedBox(width: 10),
                      Flexible(
                        child: Text(
                          a.$2,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.text2,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ))
          .toList(),
    );
  }
}

// ── Exam Tile ─────────────────────────────
class _ExamTile extends StatelessWidget {
  final String subject, time;
  final Color color;
  const _ExamTile(
      {required this.subject,
      required this.time,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
      decoration: AppTheme.card(),
      child: Row(
        children: [
          Container(
            width: 5,
            height: 42,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  subject,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.text1,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  time,
                  style: const TextStyle(
                      fontSize: 12, color: AppTheme.text3),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: color.withOpacity(0.08),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              'View',
              style: TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w500,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Recent Activity ───────────────────────
class _RecentActivity extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      (Icons.assignment_turned_in_rounded, 'Assignment Submitted',
          'Mathematics · 2h ago', AppTheme.green),
      (Icons.grade_rounded, 'Quiz Result: 88%',
          'Physics · Yesterday', AppTheme.amber),
      (Icons.menu_book_rounded, 'New Study Material',
          'Chemistry · 2 days ago', AppTheme.primary),
    ];
    return Container(
      decoration: AppTheme.card(),
      child: Column(
        children: List.generate(items.length, (i) {
          final a = items[i];
          return Column(children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              child: Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: a.$4.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(a.$1, size: 18, color: a.$4),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          a.$2,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: AppTheme.text1,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          a.$3,
                          style: const TextStyle(
                              fontSize: 12, color: AppTheme.text3),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.chevron_right_rounded,
                      size: 18, color: AppTheme.text4),
                ],
              ),
            ),
            if (i < items.length - 1)
              Container(
                height: 1,
                margin:
                    const EdgeInsets.symmetric(horizontal: 14),
                color: AppTheme.divider,
              ),
          ]);
        }),
      ),
    );
  }
}

// ── Section Title ─────────────────────────
class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) => Text(
        title,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: AppTheme.text1,
          letterSpacing: -0.2,
        ),
      );
}

// ── Bottom Nav ────────────────────────────
class _BottomNav extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onTap;
  const _BottomNav({required this.selected, required this.onTap});

  static const _tabs = [
    (Icons.home_rounded,           Icons.home_outlined,          'Home'),
    (Icons.assignment_rounded,     Icons.assignment_outlined,     'Exams'),
    (Icons.calendar_month_rounded, Icons.calendar_month_outlined, 'Schedule'),
    (Icons.person_rounded,         Icons.person_outline_rounded,  'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
            top: BorderSide(color: AppTheme.divider, width: 1)),
        boxShadow: [
          BoxShadow(
              color: Color(0x08000000),
              blurRadius: 16,
              offset: Offset(0, -4)),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 58,
          child: Row(
            children: List.generate(_tabs.length, (i) {
              final sel = i == selected;
              final t = _tabs[i];
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        decoration: sel
                            ? BoxDecoration(
                                color: AppTheme.primaryBg,
                                borderRadius:
                                    BorderRadius.circular(50),
                              )
                            : null,
                        child: Icon(
                          sel ? t.$1 : t.$2,
                          size: 22,
                          color: sel
                              ? AppTheme.primary
                              : AppTheme.text4,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        t.$3,
                        style: TextStyle(
                          fontSize: 10,
                          color: sel
                              ? AppTheme.primary
                              : AppTheme.text4,
                          fontWeight: sel
                              ? FontWeight.w600
                              : FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}
