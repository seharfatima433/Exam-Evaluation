import 'package:flutter/material.dart';
import '../controllers/course_controller.dart';
import '../models/quiz_model.dart';
import '../utils/app_theme.dart';

class QuizViewScreen extends StatefulWidget {
  final String quizCode, quizName;
  const QuizViewScreen({
    super.key,
    required this.quizCode,
    this.quizName = 'Quiz',
  });
  @override
  State<QuizViewScreen> createState() => _QuizViewScreenState();
}

class _QuizViewScreenState extends State<QuizViewScreen> {
  late final QuizViewController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = QuizViewController()
      ..addListener(() {
        if (mounted) setState(() {});
      })
      ..fetchQuiz(widget.quizCode);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          _buildAppBar(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
            bottom: BorderSide(color: AppTheme.divider, width: 1)),
        boxShadow: [
          BoxShadow(
              color: Color(0x05000000),
              blurRadius: 8,
              offset: Offset(0, 2)),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: AppTheme.bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.border, width: 1.2),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      size: 16, color: AppTheme.text2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.quizName,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.text1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 6, vertical: 1),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryBg,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            'Code: ${widget.quizCode}',
                            style: const TextStyle(
                              fontSize: 10,
                              color: AppTheme.primary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_ctrl.state == LoadState.loading) {
      return const Center(
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation(AppTheme.primary),
        ),
      );
    }
    if (_ctrl.state == LoadState.error || _ctrl.quiz == null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: AppTheme.redBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.error_outline_rounded,
                  size: 28, color: AppTheme.red),
            ),
            const SizedBox(height: 14),
            Text(
              _ctrl.error ?? 'Failed to load quiz',
              style: const TextStyle(
                  fontSize: 13, color: AppTheme.text3),
            ),
            const SizedBox(height: 18),
            TextButton(
              onPressed: () => _ctrl.fetchQuiz(widget.quizCode),
              style: TextButton.styleFrom(
                backgroundColor: AppTheme.primaryBg,
                padding: const EdgeInsets.symmetric(
                    horizontal: 24, vertical: 10),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(50),
                  side: const BorderSide(
                      color: AppTheme.primary, width: 1),
                ),
              ),
              child: const Text('Try Again',
                  style: TextStyle(
                      color: AppTheme.primary,
                      fontWeight: FontWeight.w500)),
            ),
          ],
        ),
      );
    }

    final quiz   = _ctrl.quiz!;
    final mcqs   = quiz.questions.where((q) => q.type == 'mcq').toList();
    final shorts = quiz.questions.where((q) => q.type == 'short').toList();
    final fills  = quiz.questions.where((q) => q.type == 'fill').toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      children: [
        _InfoBar(quiz: quiz),
        const SizedBox(height: 20),
        if (mcqs.isNotEmpty) ...[
          _SectionHeader(
              'Multiple Choice', mcqs.length, AppTheme.primary),
          const SizedBox(height: 10),
          ...List.generate(
            mcqs.length,
            (i) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _McqCard(q: mcqs[i], index: i + 1),
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (shorts.isNotEmpty) ...[
          _SectionHeader(
              'Short Questions', shorts.length, AppTheme.green),
          const SizedBox(height: 10),
          ...List.generate(
            shorts.length,
            (i) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _ShortCard(q: shorts[i], index: i + 1),
            ),
          ),
          const SizedBox(height: 8),
        ],
        if (fills.isNotEmpty) ...[
          _SectionHeader(
              'Fill in the Blanks', fills.length, AppTheme.violet),
          const SizedBox(height: 10),
          ...List.generate(
            fills.length,
            (i) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _FillCard(q: fills[i], index: i + 1),
            ),
          ),
        ],
        const SizedBox(height: 16),
      ],
    );
  }
}

// ── Info Bar ──────────────────────────────
class _InfoBar extends StatelessWidget {
  final FullQuiz quiz;
  const _InfoBar({required this.quiz});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.primaryGrad,
        borderRadius: BorderRadius.circular(16),
        boxShadow: AppTheme.glowShadow(AppTheme.primary),
      ),
      child: Row(
        children: [
          Expanded(
            child: Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                _InfoChip(
                    Icons.calendar_today_rounded, quiz.quizDate),
                _InfoChip(
                  Icons.access_time_rounded,
                  '${quiz.startTime.substring(0, 5)} – ${quiz.endTime.substring(0, 5)}',
                ),
                _InfoChip(
                  Icons.help_outline_rounded,
                  '${quiz.questions.length} questions',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _InfoChip(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 13, color: Colors.white70),
        const SizedBox(width: 5),
        Text(
          text,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}

// ── Section Header ────────────────────────
class _SectionHeader extends StatelessWidget {
  final String title;
  final int count;
  final Color color;
  const _SectionHeader(this.title, this.count, this.color);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
            color: AppTheme.text1,
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(
              horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(50),
          ),
          child: Text(
            '$count',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: color,
            ),
          ),
        ),
      ],
    );
  }
}

// ── MCQ Card ──────────────────────────────
class _McqCard extends StatelessWidget {
  final QuizQuestion q;
  final int index;
  const _McqCard({required this.q, required this.index});

  String _correct() {
    final ca   = q.correctAnswer ?? '';
    final opts = [q.optionA, q.optionB, q.optionC, q.optionD];
    if (ca.length == 1 && 'abcd'.contains(ca.toLowerCase())) {
      final i = 'abcd'.indexOf(ca.toLowerCase());
      return opts[i] ?? ca;
    }
    return ca;
  }

  @override
  Widget build(BuildContext context) {
    final correct = _correct();
    final opts = [
      ('A', q.optionA),
      ('B', q.optionB),
      ('C', q.optionC),
      ('D', q.optionD),
    ].where((o) => o.$2 != null).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppTheme.card(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _IndexBadge(index, AppTheme.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  q.question,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: AppTheme.text1,
                    height: 1.5,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...opts.map((o) {
            final isCorrect = o.$2 == correct;
            return Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.symmetric(
                  horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: isCorrect
                    ? AppTheme.greenBg
                    : AppTheme.bg,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isCorrect
                      ? AppTheme.green.withOpacity(0.35)
                      : AppTheme.border,
                  width: 1.2,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    width: 22,
                    height: 22,
                    decoration: BoxDecoration(
                      color: isCorrect
                          ? AppTheme.green
                          : AppTheme.border,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Center(
                      child: Text(
                        o.$1,
                        style: TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: isCorrect
                              ? Colors.white
                              : AppTheme.text3,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      o.$2!,
                      style: TextStyle(
                        fontSize: 13,
                        color: isCorrect
                            ? AppTheme.green
                            : AppTheme.text2,
                        fontWeight: isCorrect
                            ? FontWeight.w600
                            : FontWeight.w400,
                      ),
                    ),
                  ),
                  if (isCorrect)
                    const Icon(Icons.check_circle_rounded,
                        size: 16, color: AppTheme.green),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ── Short Question Card ───────────────────
class _ShortCard extends StatelessWidget {
  final QuizQuestion q;
  final int index;
  const _ShortCard({required this.q, required this.index});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.card(),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _IndexBadge(index, AppTheme.green),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                q.question,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.text1,
                  height: 1.5,
                ),
              ),
            ),
          ],
        ),
      );
}

// ── Fill Card ─────────────────────────────
class _FillCard extends StatelessWidget {
  final QuizQuestion q;
  final int index;
  const _FillCard({required this.q, required this.index});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.card(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _IndexBadge(index, AppTheme.violet),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    q.question,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: AppTheme.text1,
                      height: 1.5,
                    ),
                  ),
                ),
              ],
            ),
            if (q.correctAnswer != null) ...[
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.only(left: 32),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.violetBg,
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(
                        color: AppTheme.violet.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.check_rounded,
                          size: 13, color: AppTheme.violet),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          q.correctAnswer!,
                          style: const TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.violet,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      );
}

// ── Index Badge ───────────────────────────
class _IndexBadge extends StatelessWidget {
  final int index;
  final Color color;
  const _IndexBadge(this.index, this.color);

  @override
  Widget build(BuildContext context) => Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: color.withOpacity(0.12),
          borderRadius: BorderRadius.circular(6),
        ),
        child: Center(
          child: Text(
            '$index',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
        ),
      );
}
