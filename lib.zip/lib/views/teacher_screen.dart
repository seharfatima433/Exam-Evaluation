import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../controllers/course_controller.dart';
import '../models/course_model.dart';
import '../utils/app_theme.dart';
import 'course_quizzes_screen.dart';
import 'quiz_creation_screen.dart';

class TeacherScreen extends StatefulWidget {
  final int teacherId;
  final String teacherName;
  const TeacherScreen({
    super.key,
    required this.teacherId,
    this.teacherName = 'Teacher',
  });
  @override
  State<TeacherScreen> createState() => _TeacherScreenState();
}

class _TeacherScreenState extends State<TeacherScreen> {
  late final CourseController _ctrl;

  String get _initials {
    final p = widget.teacherName.trim().split(' ');
    if (p.length >= 2) return '${p[0][0]}${p[1][0]}'.toUpperCase();
    return widget.teacherName.isNotEmpty
        ? widget.teacherName[0].toUpperCase()
        : 'T';
  }

  @override
  void initState() {
    super.initState();
    _ctrl = CourseController()
      ..addListener(() {
        if (mounted) setState(() {});
      })
      ..fetchTeacherCourses(widget.teacherId);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          _buildAppBar(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
            bottom: BorderSide(color: AppTheme.divider, width: 1)),
        boxShadow: [
          BoxShadow(
              color: Color(0x05000000),
              blurRadius: 8,
              offset: Offset(0, 2)),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  gradient: AppTheme.greenGrad,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Text(
                    _initials,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.teacherName,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.text1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Text(
                      'My Courses',
                      style: TextStyle(
                          fontSize: 12, color: AppTheme.text3),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () =>
                    _ctrl.fetchTeacherCourses(widget.teacherId),
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: AppTheme.bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.border, width: 1.2),
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      size: 20, color: AppTheme.text2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_ctrl.state == LoadState.loading) {
      return const Center(
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation(AppTheme.primary),
        ),
      );
    }
    if (_ctrl.state == LoadState.error) {
      return _ErrorState(
        message: _ctrl.error ?? 'Failed to load',
        onRetry: () => _ctrl.fetchTeacherCourses(widget.teacherId),
      );
    }
    if (_ctrl.courses.isEmpty) {
      return const _EmptyState(message: 'No courses assigned yet');
    }

    return RefreshIndicator(
      onRefresh: () => _ctrl.fetchTeacherCourses(widget.teacherId),
      color: AppTheme.primary,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          _StatsRow(
            courseCount: _ctrl.courseCount,
            studentCount: _ctrl.totalStudents,
          ),
          const SizedBox(height: 20),
          const _SectionTitle('Your Courses'),
          const SizedBox(height: 12),
          ...List.generate(_ctrl.courses.length, (i) {
            final course = _ctrl.courses[i];
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _CourseCard(
                course: course,
                colorIndex: i,
                onCreateQuiz: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => QuizCreationScreen(
                      teacherId: widget.teacherId,
                      course: course,
                    ),
                  ),
                ),
                onViewQuizzes: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CourseQuizzesScreen(
                      teacherId: widget.teacherId,
                      course: course,
                    ),
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ── Stats Row ─────────────────────────────
class _StatsRow extends StatelessWidget {
  final int courseCount, studentCount;
  const _StatsRow(
      {required this.courseCount, required this.studentCount});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: _StatCard(
            label: 'Courses',
            value: '$courseCount',
            icon: Icons.menu_book_rounded,
            color: AppTheme.primary,
            bg: AppTheme.primaryBg,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _StatCard(
            label: 'Students',
            value: '$studentCount',
            icon: Icons.people_rounded,
            color: AppTheme.green,
            bg: AppTheme.greenBg,
          ),
        ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color, bg;
  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppTheme.card(borderColor: color.withOpacity(0.18)),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: bg,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 20, color: color),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: color,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                label,
                style: const TextStyle(
                    fontSize: 12, color: AppTheme.text3),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Section Title ─────────────────────────
class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);

  @override
  Widget build(BuildContext context) => Text(
        title,
        style: const TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.w600,
          color: AppTheme.text1,
          letterSpacing: -0.2,
        ),
      );
}

// ── Course Card ───────────────────────────
class _CourseCard extends StatelessWidget {
  final Course course;
  final int colorIndex;
  final VoidCallback onCreateQuiz, onViewQuizzes;

  static const _colors = [
    AppTheme.primary,
    AppTheme.green,
    AppTheme.violet,
    AppTheme.amber,
    AppTheme.teal,
  ];
  static const _bgs = [
    AppTheme.primaryBg,
    AppTheme.greenBg,
    AppTheme.violetBg,
    AppTheme.amberBg,
    AppTheme.tealBg,
  ];

  const _CourseCard({
    required this.course,
    required this.colorIndex,
    required this.onCreateQuiz,
    required this.onViewQuizzes,
  });

  @override
  Widget build(BuildContext context) {
    final color = _colors[colorIndex % _colors.length];
    final bg    = _bgs[colorIndex % _bgs.length];
    return Container(
      decoration: AppTheme.card(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: bg,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
              ),
              border: const Border(
                  bottom: BorderSide(color: AppTheme.border, width: 1)),
            ),
            child: Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(Icons.menu_book_rounded,
                      size: 22, color: color),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        course.courseTitle,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.text1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(
                              color: color.withOpacity(0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              'ID: ${course.id}',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w500,
                                color: color,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Actions
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: _ActionBtn(
                    label: 'Create Quiz',
                    icon: Icons.add_circle_outline_rounded,
                    primary: true,
                    color: color,
                    onTap: onCreateQuiz,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: _ActionBtn(
                    label: 'View Quizzes',
                    icon: Icons.list_alt_rounded,
                    primary: false,
                    color: color,
                    onTap: onViewQuizzes,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool primary;
  final Color color;
  final VoidCallback onTap;
  const _ActionBtn({
    required this.label,
    required this.icon,
    required this.primary,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.selectionClick();
        onTap();
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: primary ? color : AppTheme.bg,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: primary ? color : AppTheme.border,
            width: 1.2,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: 15,
                color: primary ? Colors.white : AppTheme.text2),
            const SizedBox(width: 6),
            Flexible(
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: primary ? Colors.white : AppTheme.text2,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Empty / Error States ──────────────────
class _EmptyState extends StatelessWidget {
  final String message;
  const _EmptyState({required this.message});

  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppTheme.primaryBg,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(Icons.inbox_rounded,
                  size: 32, color: AppTheme.primary),
            ),
            const SizedBox(height: 14),
            Text(message,
                style: const TextStyle(
                    fontSize: 14, color: AppTheme.text3)),
          ],
        ),
      );
}

class _ErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorState(
      {required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  color: AppTheme.redBg,
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Icon(Icons.wifi_off_rounded,
                    size: 30, color: AppTheme.red),
              ),
              const SizedBox(height: 14),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13, color: AppTheme.text3),
              ),
              const SizedBox(height: 18),
              TextButton(
                onPressed: onRetry,
                style: TextButton.styleFrom(
                  backgroundColor: AppTheme.primaryBg,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                    side: const BorderSide(
                        color: AppTheme.primary, width: 1),
                  ),
                ),
                child: const Text(
                  'Try Again',
                  style: TextStyle(
                      color: AppTheme.primary,
                      fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
        ),
      );
}
