import 'package:flutter/material.dart';
import '../controllers/course_controller.dart';
import '../models/course_model.dart';
import '../models/quiz_model.dart';
import '../utils/app_theme.dart';
import 'quiz_view_screen.dart';

class CourseQuizzesScreen extends StatefulWidget {
  final int teacherId;
  final Course course;
  const CourseQuizzesScreen({
    super.key,
    required this.teacherId,
    required this.course,
  });
  @override
  State<CourseQuizzesScreen> createState() =>
      _CourseQuizzesScreenState();
}

class _CourseQuizzesScreenState
    extends State<CourseQuizzesScreen> {
  late final QuizListController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = QuizListController()
      ..addListener(() {
        if (mounted) setState(() {});
      })
      ..fetchCourseQuizzes(widget.teacherId, widget.course.id);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bg,
      body: Column(
        children: [
          _buildAppBar(),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _buildAppBar() {
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(
            bottom: BorderSide(color: AppTheme.divider, width: 1)),
        boxShadow: [
          BoxShadow(
              color: Color(0x05000000),
              blurRadius: 8,
              offset: Offset(0, 2)),
        ],
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: AppTheme.bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.border, width: 1.2),
                  ),
                  child: const Icon(Icons.arrow_back_ios_new_rounded,
                      size: 16, color: AppTheme.text2),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      widget.course.courseTitle,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.text1,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Text(
                      'Saved Quizzes',
                      style: TextStyle(
                          fontSize: 12, color: AppTheme.text3),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: () => _ctrl.fetchCourseQuizzes(
                    widget.teacherId, widget.course.id),
                child: Container(
                  width: 38,
                  height: 38,
                  decoration: BoxDecoration(
                    color: AppTheme.bg,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.border, width: 1.2),
                  ),
                  child: const Icon(Icons.refresh_rounded,
                      size: 20, color: AppTheme.text2),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_ctrl.state == LoadState.loading) {
      return const Center(
        child: CircularProgressIndicator(
          strokeWidth: 2,
          valueColor: AlwaysStoppedAnimation(AppTheme.primary),
        ),
      );
    }
    if (_ctrl.state == LoadState.error) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: AppTheme.redBg,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.wifi_off_rounded,
                    size: 28, color: AppTheme.red),
              ),
              const SizedBox(height: 14),
              Text(
                _ctrl.error ?? 'Failed to load',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 13, color: AppTheme.text3),
              ),
              const SizedBox(height: 18),
              TextButton(
                onPressed: () => _ctrl.fetchCourseQuizzes(
                    widget.teacherId, widget.course.id),
                style: TextButton.styleFrom(
                  backgroundColor: AppTheme.primaryBg,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 24, vertical: 10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(50),
                    side: const BorderSide(
                        color: AppTheme.primary, width: 1),
                  ),
                ),
                child: const Text('Try Again',
                    style: TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w500)),
              ),
            ],
          ),
        ),
      );
    }
    if (_ctrl.quizzes.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: AppTheme.primaryBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Icon(Icons.quiz_outlined,
                  size: 28, color: AppTheme.primary),
            ),
            const SizedBox(height: 14),
            const Text(
              'No quizzes yet',
              style: TextStyle(
                  fontSize: 14,
                  color: AppTheme.text3,
                  fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 4),
            const Text(
              'Create your first quiz to get started',
              style: TextStyle(
                  fontSize: 12, color: AppTheme.text4),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () => _ctrl.fetchCourseQuizzes(
          widget.teacherId, widget.course.id),
      color: AppTheme.primary,
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _ctrl.quizzes.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (ctx, i) => _QuizTile(
          quiz: _ctrl.quizzes[i],
          onTap: () => Navigator.push(
            ctx,
            MaterialPageRoute(
              builder: (_) => QuizViewScreen(
                quizCode: _ctrl.quizzes[i].quizCode,
                quizName: _ctrl.quizzes[i].quizName,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _QuizTile extends StatelessWidget {
  final QuizSummary quiz;
  final VoidCallback onTap;
  const _QuizTile({required this.quiz, required this.onTap});

  Color get _diffColor => quiz.difficulty == 'easy'
      ? AppTheme.green
      : quiz.difficulty == 'hard'
          ? AppTheme.red
          : AppTheme.amber;

  Color get _diffBg => quiz.difficulty == 'easy'
      ? AppTheme.greenBg
      : quiz.difficulty == 'hard'
          ? AppTheme.redBg
          : AppTheme.amberBg;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: AppTheme.card(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    quiz.quizName,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.text1,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 9, vertical: 4),
                  decoration: BoxDecoration(
                    color: _diffBg,
                    borderRadius: BorderRadius.circular(50),
                    border: Border.all(
                        color: _diffColor.withOpacity(0.3)),
                  ),
                  child: Text(
                    quiz.difficulty,
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w500,
                      color: _diffColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 14,
              runSpacing: 6,
              children: [
                _MetaChip(Icons.tag_rounded, quiz.quizCode),
                _MetaChip(
                    Icons.calendar_today_rounded, quiz.quizDate),
                _MetaChip(Icons.help_outline_rounded,
                    '${quiz.totalQuestions} questions'),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                _MetaChip(
                  Icons.access_time_rounded,
                  '${quiz.startTime.substring(0, 5)} – ${quiz.endTime.substring(0, 5)}',
                ),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryBg,
                    borderRadius: BorderRadius.circular(50),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        'View Quiz',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          color: AppTheme.primary,
                        ),
                      ),
                      SizedBox(width: 4),
                      Icon(Icons.arrow_forward_rounded,
                          size: 12, color: AppTheme.primary),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MetaChip extends StatelessWidget {
  final IconData icon;
  final String text;
  const _MetaChip(this.icon, this.text);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 12, color: AppTheme.text4),
        const SizedBox(width: 4),
        Text(
          text,
          style: const TextStyle(
              fontSize: 12, color: AppTheme.text3),
        ),
      ],
    );
  }
}
