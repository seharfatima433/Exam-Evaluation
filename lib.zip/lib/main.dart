import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/local_quiz_db.dart';
import 'utils/app_theme.dart';
import 'views/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Pre-open the local database so first access is instant
  await LocalQuizDb().db;

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'AI Based Evaluation',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.theme,
    home: const LoginScreen(),
  );
}
