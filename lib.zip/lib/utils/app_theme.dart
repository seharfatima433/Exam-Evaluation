import 'package:flutter/material.dart';

class AppTheme {
  // ── Refined Soft Palette ──────────────────
  static const Color primary     = Color(0xFF5B6CF6); // Soft indigo
  static const Color primaryDark = Color(0xFF4251D8);
  static const Color primaryBg   = Color(0xFFF0F1FF);
  static const Color primaryLight = Color(0xFFE8EAFF);

  static const Color green       = Color(0xFF34B97A); // Sage green
  static const Color greenBg     = Color(0xFFECFBF3);
  static const Color greenLight  = Color(0xFFD1F5E3);

  static const Color amber       = Color(0xFFE09B3D); // Warm amber
  static const Color amberBg     = Color(0xFFFFF8ED);
  static const Color amberLight  = Color(0xFFFFEDD0);

  static const Color red         = Color(0xFFEF5B6B); // Soft rose
  static const Color redBg       = Color(0xFFFFF0F1);
  static const Color redLight    = Color(0xFFFFDDE0);

  static const Color violet      = Color(0xFF8B6FE8); // Soft purple
  static const Color violetBg    = Color(0xFFF4F1FF);
  static const Color violetLight = Color(0xFFEAE4FF);

  static const Color teal        = Color(0xFF3BBFB0);
  static const Color tealBg      = Color(0xFFEBFAF8);

  // ── Neutrals ──────────────────────────────
  static const Color bg          = Color(0xFFF6F7FB);
  static const Color surface     = Color(0xFFFFFFFF);
  static const Color surfaceAlt  = Color(0xFFFBFBFE);
  static const Color border      = Color(0xFFEAEBF4);
  static const Color borderMid   = Color(0xFFD8DAF0);
  static const Color divider     = Color(0xFFF0F1F8);

  // ── Text ──────────────────────────────────
  static const Color text1       = Color(0xFF1A1D35);
  static const Color text2       = Color(0xFF3D4168);
  static const Color text3       = Color(0xFF7C80A8);
  static const Color text4       = Color(0xFFB0B4CF);

  // ── Gradients ─────────────────────────────
  static const LinearGradient primaryGrad = LinearGradient(
    colors: [Color(0xFF5B6CF6), Color(0xFF7E8DF9)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient primaryGradDeep = LinearGradient(
    colors: [Color(0xFF4251D8), Color(0xFF5B6CF6)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient greenGrad = LinearGradient(
    colors: [Color(0xFF2CA86A), Color(0xFF34B97A)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );
  static const LinearGradient heroGrad = LinearGradient(
    colors: [Color(0xFF4F5EE8), Color(0xFF6E7DF5), Color(0xFF8B6FE8)],
    begin: Alignment.topLeft, end: Alignment.bottomRight,
  );

  // ── Theme ─────────────────────────────────
  static ThemeData get theme => ThemeData(
    useMaterial3: false,
    scaffoldBackgroundColor: bg,
    colorScheme: const ColorScheme.light(
      primary: primary,
      secondary: violet,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: surface,
      foregroundColor: text1,
      elevation: 0,
      titleTextStyle: TextStyle(
        fontSize: 17, fontWeight: FontWeight.w600,
        color: text1, letterSpacing: -0.3,
      ),
      iconTheme: IconThemeData(color: text2, size: 22),
    ),
    textTheme: const TextTheme(
      bodyMedium: TextStyle(fontSize: 14, color: text2, height: 1.5),
    ),
  );

  // ── Card decoration ───────────────────────
  static BoxDecoration card({Color? borderColor, double radius = 16}) =>
      BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor ?? border, width: 1.2),
        boxShadow: const [
          BoxShadow(
              color: Color(0x07000000), blurRadius: 12, offset: Offset(0, 4)),
          BoxShadow(
              color: Color(0x04000000), blurRadius: 4, offset: Offset(0, 1)),
        ],
      );

  static BoxDecoration cardElevated({Color? borderColor}) => BoxDecoration(
    color: surface,
    borderRadius: BorderRadius.circular(20),
    border: Border.all(color: borderColor ?? border, width: 1),
    boxShadow: const [
      BoxShadow(
          color: Color(0x0C000000), blurRadius: 24, offset: Offset(0, 8)),
      BoxShadow(
          color: Color(0x06000000), blurRadius: 6, offset: Offset(0, 2)),
    ],
  );

  static BoxDecoration pill(Color bg, Color borderColor) => BoxDecoration(
    color: bg,
    borderRadius: BorderRadius.circular(50),
    border: Border.all(color: borderColor, width: 1),
  );

  static BoxDecoration pillRect(Color bg, Color borderColor,
      {double radius = 8}) =>
      BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: borderColor, width: 1),
      );

  static List<BoxShadow> glowShadow(Color color) => [
    BoxShadow(
        color: color.withOpacity(0.28),
        blurRadius: 20,
        offset: const Offset(0, 8)),
    BoxShadow(
        color: color.withOpacity(0.1),
        blurRadius: 6,
        offset: const Offset(0, 2)),
  ];
}
