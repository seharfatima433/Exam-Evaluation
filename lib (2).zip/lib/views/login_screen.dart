import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../controllers/auth_controller.dart';
import '../utils/app_theme.dart';
import 'teacher_screen.dart';
import 'student_screen.dart';

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) =>
      super.createHttpClient(context)
        ..badCertificateCallback = (_, __, ___) => true;
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen>
    with SingleTickerProviderStateMixin {
  final _inputCtrl    = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _authCtrl     = AuthController();
  bool _obscure = true;
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    HttpOverrides.global = MyHttpOverrides();
    _authCtrl.addListener(() { if (mounted) setState(() {}); });
    _animCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _animCtrl.forward();
  }

  @override
  void dispose() {
    _inputCtrl.dispose();
    _passwordCtrl.dispose();
    _authCtrl.dispose();
    _animCtrl.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final input = _inputCtrl.text.trim();
    final pass  = _passwordCtrl.text.trim();
    if (input.isEmpty || pass.isEmpty) { _snack('Please fill in all fields'); return; }
    HapticFeedback.lightImpact();
    final ok = await _authCtrl.login(input, pass);
    if (!mounted) return;
    if (ok) {
      final user = _authCtrl.currentUser!;
      Widget dest = user.role == 'teacher'
          ? TeacherScreen(teacherId: user.id, teacherName: user.name)
          : StudentScreen(
              studentName: user.name,
              studentId: user.id,
              rollNo: user.rollNo,
            );
      Navigator.pushReplacement(
          context,
          PageRouteBuilder(
            pageBuilder: (_, a, __) => dest,
            transitionsBuilder: (_, a, __, child) =>
                FadeTransition(opacity: a, child: child),
            transitionDuration: const Duration(milliseconds: 340),
          ));
    } else {
      _snack(_authCtrl.errorMessage ?? 'Login failed');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: GoogleFonts.outfit(fontSize: 13, color: Colors.white)),
      backgroundColor: AppTheme.text1,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(16),
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          gradient: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.splashGrad
              : LinearGradient(
                  colors: [
                    const Color(0xFFE3F2FD),
                    const Color(0xFFBBDEFB).withOpacity(0.5),
                    Colors.white,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
        ),
        child: SafeArea(
          child: Stack(
            children: [
              // Background blobs
              _blob(top: -80, right: -80, size: 260,
                  color: AppTheme.primary.withOpacity(0.16)),
              _blob(bottom: 60, left: -70, size: 210,
                  color: AppTheme.primaryLighter.withOpacity(0.10)),

              FadeTransition(
                opacity: _fadeAnim,
                child: Center(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 22, vertical: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _buildHeader(),
                        const SizedBox(height: 30),
                        _buildLoginCard(),
                        const SizedBox(height: 22),
                        _buildRoleBadges(),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _blob({double? top, double? bottom, double? left, double? right,
      required double size, required Color color}) {
    return Positioned(
      top: top, bottom: bottom, left: left, right: right,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, Colors.transparent]),
        ),
      ),
    );
  }

  // ── Header ───────────────────────────────────────────────────
  Widget _buildHeader() {
    return Column(
      children: [
        // Logo icon
        Container(
          width: 88, height: 88,
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF1565C0), Color(0xFF1E88E5), Color(0xFF42A5F5)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            boxShadow: AppTheme.glowShadow(AppTheme.primary),
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Positioned(top: 12, right: 12,
                child: Container(width: 14, height: 14,
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.18),
                        shape: BoxShape.circle))),
              Positioned(bottom: 12, left: 12,
                child: Container(width: 8, height: 8,
                    decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.13),
                        shape: BoxShape.circle))),
              const Icon(Icons.school_rounded, color: Colors.white, size: 40),
            ],
          ),
        )
            .animate()
            .scaleXY(
                begin: 0.55, end: 1.0,
                duration: 650.ms, curve: Curves.elasticOut)
            .fadeIn(duration: 450.ms),

        const SizedBox(height: 18),

        Text(
          'EduQuiz',
          style: GoogleFonts.outfit(
              fontSize: 38, fontWeight: FontWeight.w800,
              color: Colors.white, letterSpacing: -1.4),
        )
            .animate(delay: 120.ms)
            .fadeIn(duration: 500.ms)
            .slideY(begin: 0.25, end: 0, duration: 500.ms),

        const SizedBox(height: 6),

        Text(
          'AI-powered evaluation system',
          style: GoogleFonts.outfit(
              fontSize: 13,
              color: Theme.of(context).brightness == Brightness.dark
                  ? AppTheme.textOnDark2
                  : AppTheme.text3),
        )
            .animate(delay: 220.ms)
            .fadeIn(duration: 500.ms)
            .slideY(begin: 0.2, end: 0, duration: 500.ms),
      ],
    );
  }

  // ── Login card ────────────────────────────────────────────────
  Widget _buildLoginCard() {
    return Container(
      width: double.infinity,
      decoration: AppTheme.themedCard(context, radius: 24).copyWith(
        boxShadow: Theme.of(context).brightness == Brightness.dark
            ? [
                BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 55,
                    offset: const Offset(0, 22))
              ]
            : [
                const BoxShadow(
                    color: Color(0x261565C0),
                    blurRadius: 55,
                    offset: Offset(0, 22)),
                const BoxShadow(
                    color: Color(0x0E000000),
                    blurRadius: 10,
                    offset: Offset(0, 4)),
              ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Column(
          children: [
            // Gradient accent strip
            Container(
              height: 4,
              decoration: const BoxDecoration(gradient: AppTheme.primaryGrad),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 22, 24, 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Welcome back 👋',
                      style: GoogleFonts.outfit(
                          fontSize: 22, fontWeight: FontWeight.w800,
                          color: AppTheme.text1, letterSpacing: -0.5)),
                  const SizedBox(height: 4),
                  Text('Sign in to your account',
                      style: GoogleFonts.outfit(
                          fontSize: 13,
                          color: Theme.of(context).brightness == Brightness.dark
                              ? AppTheme.darkText3
                              : AppTheme.text3)),
                  const SizedBox(height: 22),
                  _buildTextField(
                    controller: _inputCtrl,
                    label: 'Email or Roll Number',
                    hint: 'you@example.com',
                    icon: Icons.person_outline_rounded,
                  ),
                  const SizedBox(height: 14),
                  _buildPasswordField(),
                  const SizedBox(height: 6),
                  Align(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 4),
                        foregroundColor: AppTheme.primary,
                        minimumSize: Size.zero,
                        tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                      ),
                      child: Text('Forgot Password?',
                          style: GoogleFonts.outfit(
                              fontSize: 12, color: AppTheme.primary,
                              fontWeight: FontWeight.w600)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildSignInButton(),
                ],
              ),
            ),
          ],
        ),
      ),
    )
        .animate(delay: 320.ms)
        .fadeIn(duration: 550.ms)
        .slideY(begin: 0.12, end: 0, duration: 550.ms, curve: Curves.easeOut);
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
  }) {
    return TextField(
      controller: controller,
      style: GoogleFonts.outfit(
          fontSize: 14,
          color: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.darkText1
              : AppTheme.text1),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Icon(icon, size: 18, color: AppTheme.text4),
        ),
        prefixIconConstraints:
            const BoxConstraints(minWidth: 46, minHeight: 46),
        filled: true,
        fillColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.darkInput
            : const Color(0xFFF5F7FF),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppTheme.darkBorder
                    : AppTheme.border,
                width: 1.2)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppTheme.darkBorder
                    : AppTheme.border,
                width: 1.2)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? const Color(0xFF42A5F5)
                    : AppTheme.primary,
                width: 2.0)),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: GoogleFonts.outfit(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppTheme.darkText3
                : AppTheme.text3,
            fontSize: 13),
        hintStyle: GoogleFonts.outfit(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppTheme.darkText4
                : AppTheme.text4,
            fontSize: 13),
      ),
    );
  }

  Widget _buildPasswordField() {
    return TextField(
      controller: _passwordCtrl,
      obscureText: _obscure,
      style: GoogleFonts.outfit(
          fontSize: 14,
          color: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.darkText1
              : AppTheme.text1),
      decoration: InputDecoration(
        labelText: 'Password',
        hintText: 'Enter your password',
        prefixIcon: const Padding(
          padding: EdgeInsets.symmetric(horizontal: 12),
          child:
              Icon(Icons.lock_outline_rounded, size: 18, color: AppTheme.text4),
        ),
        prefixIconConstraints:
            const BoxConstraints(minWidth: 46, minHeight: 46),
        suffixIcon: IconButton(
          icon: Icon(
            _obscure
                ? Icons.visibility_off_outlined
                : Icons.visibility_outlined,
            size: 18, color: AppTheme.text4,
          ),
          onPressed: () => setState(() => _obscure = !_obscure),
          splashRadius: 18,
        ),
        filled: true,
        fillColor: Theme.of(context).brightness == Brightness.dark
            ? AppTheme.darkInput
            : const Color(0xFFF5F7FF),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppTheme.darkBorder
                    : AppTheme.border,
                width: 1.2)),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppTheme.darkBorder
                    : AppTheme.border,
                width: 1.2)),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
                color: Theme.of(context).brightness == Brightness.dark
                    ? const Color(0xFF42A5F5)
                    : AppTheme.primary,
                width: 2.0)),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: GoogleFonts.outfit(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppTheme.darkText3
                : AppTheme.text3,
            fontSize: 13),
        hintStyle: GoogleFonts.outfit(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppTheme.darkText4
                : AppTheme.text4,
            fontSize: 13),
      ),
    );
  }

  Widget _buildSignInButton() {
    return _TapScaleButton(
      onTap: _authCtrl.isLoading ? null : _login,
      child: Container(
        width: double.infinity,
        height: 52,
        decoration: BoxDecoration(
          gradient: AppTheme.heroGrad,
          borderRadius: BorderRadius.circular(14),
          boxShadow: AppTheme.glowShadow(AppTheme.primary),
        ),
        child: Center(
          child: _authCtrl.isLoading
              ? const SizedBox(
                  width: 22, height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2.5,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('Sign In',
                        style: GoogleFonts.outfit(
                            fontSize: 16, fontWeight: FontWeight.w700,
                            color: Colors.white, letterSpacing: 0.4)),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward_rounded,
                        color: Colors.white, size: 18),
                  ],
                ),
        ),
      ),
    );
  }

  Widget _buildRoleBadges() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _RoleBadge(
          icon: Icons.cast_for_education_rounded,
          label: 'Teacher',
          color: Theme.of(context).brightness == Brightness.dark
              ? Colors.white
              : AppTheme.primary,
          bg: Theme.of(context).brightness == Brightness.dark
              ? Colors.white.withOpacity(0.12)
              : AppTheme.primary.withOpacity(0.08),
          borderColor: Theme.of(context).brightness == Brightness.dark
              ? Colors.white.withOpacity(0.25)
              : AppTheme.primary.withOpacity(0.20),
        ),
        const SizedBox(width: 10),
        _RoleBadge(
          icon: Icons.school_rounded,
          label: 'Student',
          color: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.primaryLighter
              : AppTheme.violet,
          bg: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.primary.withOpacity(0.22)
              : AppTheme.violet.withOpacity(0.08),
          borderColor: Theme.of(context).brightness == Brightness.dark
              ? AppTheme.primaryLighter.withOpacity(0.35)
              : AppTheme.violet.withOpacity(0.20),
        ),
      ],
    ).animate(delay: 520.ms).fadeIn(duration: 500.ms);
  }
}

// ── Tap-scale micro-interaction ───────────────────────────────────
class _TapScaleButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  const _TapScaleButton({required this.child, this.onTap});
  @override
  State<_TapScaleButton> createState() => _TapScaleButtonState();
}

class _TapScaleButtonState extends State<_TapScaleButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _s;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 100));
    _s = Tween<double>(begin: 1.0, end: 0.965)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }

  @override
  void dispose() { _c.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _c.forward(),
      onTapUp: (_) { _c.reverse(); widget.onTap?.call(); },
      onTapCancel: () => _c.reverse(),
      child: ScaleTransition(scale: _s, child: widget.child),
    );
  }
}

// ── Role badge ────────────────────────────────────────────────────
class _RoleBadge extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color, bg, borderColor;
  const _RoleBadge({
    required this.icon, required this.label,
    required this.color, required this.bg, required this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(50),
        border: Border.all(color: borderColor, width: 1.2),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 12, color: color),
          const SizedBox(width: 6),
          Text(label,
              style: GoogleFonts.outfit(
                  fontSize: 12, fontWeight: FontWeight.w600, color: color)),
        ],
      ),
    );
  }
}
