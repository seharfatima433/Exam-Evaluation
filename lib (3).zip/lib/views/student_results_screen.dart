import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import '../services/student_service.dart';
import '../utils/app_theme.dart';
import '../widgets/premium_app_bar.dart';
import 'student_quiz_screen.dart'; // To show quiz result

class StudentResultsScreen extends StatefulWidget {
  final int studentId;
  final String studentName;

  const StudentResultsScreen({
    super.key,
    required this.studentId,
    required this.studentName,
  });

  @override
  State<StudentResultsScreen> createState() => _StudentResultsScreenState();
}

class _StudentResultsScreenState extends State<StudentResultsScreen> {
  final _service = StudentService();
  bool _loading = true;
  String? _error;
  List<dynamic> _results = [];

  @override
  void initState() {
    super.initState();
    _loadResults();
  }

  Future<void> _loadResults() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final res = await _service.fetchStudentResults(widget.studentId);
    if (!mounted) return;

    if (res['success'] == true) {
      setState(() {
        _results = res['data']?['data'] ?? res['data'] ?? [];
        _loading = false;
      });
    } else {
      setState(() {
        _error = res['message'];
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: Column(
        children: [
          PremiumAppBar(
            title: 'My Quiz Results',
            subtitle: widget.studentName,
            showBack: true,
          ),
          Expanded(child: _buildBody(isDark)),
        ],
      ),
    );
  }

  Widget _buildBody(bool isDark) {
    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(strokeWidth: 2.5, valueColor: AlwaysStoppedAnimation(AppTheme.primary)),
      );
    }

    if (_error != null) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, color: AppTheme.red, size: 48),
            const SizedBox(height: 16),
            Text(_error!, style: GoogleFonts.outfit(color: AppTheme.red, fontSize: 14)),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _loadResults,
              icon: const Icon(Icons.refresh_rounded, size: 18),
              label: Text('Retry', style: GoogleFonts.outfit(fontWeight: FontWeight.w600)),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ],
        ),
      );
    }

    if (_results.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80, height: 80,
              decoration: BoxDecoration(color: AppTheme.amber.withOpacity(0.15), shape: BoxShape.circle),
              child: const Icon(Icons.assignment_turned_in_rounded, color: AppTheme.amber, size: 36),
            ),
            const SizedBox(height: 16),
            Text('No Past Results', style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.w800, color: isDark ? AppTheme.darkText1 : AppTheme.text1)),
            const SizedBox(height: 8),
            Text('You haven\'t completed any quizzes yet\nthat have unlocked results.', textAlign: TextAlign.center, style: GoogleFonts.outfit(fontSize: 13, color: isDark ? AppTheme.darkText3 : AppTheme.text3)),
          ],
        ),
      ).animate().fadeIn().slideY(begin: 0.1, end: 0);
    }

    return RefreshIndicator(
      onRefresh: _loadResults,
      color: AppTheme.primary,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _results.length,
        itemBuilder: (context, index) {
          final result = _results[index];
          return _ResultCard(result: result, index: index);
        },
      ),
    );
  }
}

class _ResultCard extends StatelessWidget {
  final Map<String, dynamic> result;
  final int index;

  const _ResultCard({required this.result, required this.index});

  void _showResultDetails(BuildContext context, Map<String, dynamic> result, bool isDark) {
    int parseIntSafe(dynamic v) {
      if (v == null) return 0;
      if (v is int) return v;
      if (v is double) return v.round();
      return int.tryParse(v.toString()) ?? 0;
    }

    final score = parseIntSafe(result['score']);
    final total = parseIntSafe(result['total_questions']);
    final correct = parseIntSafe(result['correct_answers']);
    final wrong = parseIntSafe(result['wrong_answers']);
    final percentage = parseIntSafe(result['percentage']);
    final isPass = percentage >= 50;

    final quizCode = result['quiz_code']?.toString() ?? 'Unknown';
    final courseName = result['course_name']?.toString() ?? result['course_title']?.toString() ?? '';
    final quizName = result['quiz_name']?.toString() ?? '';
    final submittedAt = result['submitted_at']?.toString() ?? 'N/A';
    final startTime = result['start_time']?.toString() ?? 'N/A';
    final endTime = result['end_time']?.toString() ?? 'N/A';
    
    final color = isPass ? AppTheme.greenDark : AppTheme.amber;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: isDark ? AppTheme.darkSurface : AppTheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(width: 40, height: 4, decoration: BoxDecoration(color: isDark ? AppTheme.darkBorder : AppTheme.border, borderRadius: BorderRadius.circular(2))),
              const SizedBox(height: 24),
              
              // Header
              Container(
                width: 80, height: 80,
                decoration: BoxDecoration(
                  gradient: isPass ? AppTheme.greenGrad : AppTheme.primaryGrad,
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    '$percentage%',
                    style: GoogleFonts.outfit(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                courseName.isNotEmpty ? courseName : 'Quiz: $quizCode',
                style: GoogleFonts.outfit(fontSize: 20, fontWeight: FontWeight.w800, color: isDark ? AppTheme.darkText1 : AppTheme.text1),
                textAlign: TextAlign.center,
              ),
              if (quizName.isNotEmpty)
                Text(quizName, style: GoogleFonts.outfit(fontSize: 14, color: isDark ? AppTheme.darkText3 : AppTheme.text3)),
              
              const SizedBox(height: 24),

              // Stats Grid
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.center,
                children: [
                  _DetailBox('Score', '$score/$total', color, isDark),
                  _DetailBox('Correct', '$correct', AppTheme.greenDark, isDark),
                  _DetailBox('Wrong', '$wrong', AppTheme.red, isDark),
                ],
              ),
              
              const SizedBox(height: 24),
              const Divider(),
              const SizedBox(height: 12),

              // Timing Info
              _TimingRow('Scheduled Start', startTime, isDark),
              _TimingRow('Scheduled End', endTime, isDark),
              _TimingRow('Submitted At', submittedAt, isDark),
              
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: () => Navigator.pop(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: isDark ? AppTheme.darkInput : AppTheme.surfaceAlt,
                    foregroundColor: isDark ? AppTheme.darkText1 : AppTheme.text1,
                    elevation: 0,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                  ),
                  child: Text('Close', style: GoogleFonts.outfit(fontWeight: FontWeight.w700, fontSize: 15)),
                ),
              ),
              SizedBox(height: MediaQuery.of(context).padding.bottom),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    int parseIntSafe(dynamic v) {
      if (v == null) return 0;
      if (v is int) return v;
      if (v is double) return v.round();
      return int.tryParse(v.toString()) ?? 0;
    }

    final score = parseIntSafe(result['score']);
    final total = parseIntSafe(result['total_questions']);
    final percentage = parseIntSafe(result['percentage']);
    final isPass = percentage >= 50;

    final quizCode = result['quiz_code']?.toString() ?? 'Unknown';
    final courseName = result['course_name']?.toString() ?? result['course_title']?.toString();
    final displayName = courseName != null ? '$courseName ($quizCode)' : 'Quiz: $quizCode';

    final submittedAt = result['submitted_at']?.toString() ?? '';
    final dateOnly = submittedAt.length >= 10 ? submittedAt.substring(0, 10) : submittedAt;

    final color = isPass ? AppTheme.greenDark : AppTheme.amber;
    final grad = isPass ? AppTheme.greenGrad : AppTheme.accentGrad;
    final bg   = isPass ? AppTheme.greenBg   : AppTheme.amberBg;

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: AppTheme.themedCard(context),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () {
              HapticFeedback.lightImpact();
              _showResultDetails(context, result, isDark);
            },
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Tinted header ─────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: isDark ? color.withOpacity(0.08) : bg,
                    border: Border(
                        bottom: BorderSide(
                            color: isDark ? AppTheme.darkBorder : AppTheme.border,
                            width: 1)),
                  ),
                  child: Row(
                    children: [
                      // Gradient score badge
                      Container(
                        width: 48, height: 48,
                        decoration: BoxDecoration(
                          gradient: grad,
                          borderRadius: BorderRadius.circular(13),
                          boxShadow: [
                            BoxShadow(
                                color: color.withOpacity(0.30),
                                blurRadius: 10, offset: const Offset(0, 4))
                          ],
                        ),
                        child: Center(
                          child: Text(
                            '$percentage%',
                            style: GoogleFonts.outfit(
                              fontSize: 13,
                              fontWeight: FontWeight.w800,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              displayName,
                              style: GoogleFonts.outfit(
                                fontSize: 14, fontWeight: FontWeight.w700,
                                color: isDark ? AppTheme.darkText1 : AppTheme.text1,
                              ),
                              maxLines: 1, overflow: TextOverflow.ellipsis,
                            ),
                            const SizedBox(height: 4),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                              decoration: BoxDecoration(
                                color: color.withOpacity(0.10),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                isPass ? 'PASSED' : 'NEEDS IMPROVEMENT',
                                style: GoogleFonts.outfit(
                                    fontSize: 9, fontWeight: FontWeight.w700,
                                    color: color, letterSpacing: 0.4),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                // ── Bottom detail row ─────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Row(
                    children: [
                      Icon(Icons.calendar_today_rounded,
                          size: 12, color: isDark ? AppTheme.darkText4 : AppTheme.text4),
                      const SizedBox(width: 5),
                      Text(dateOnly,
                          style: GoogleFonts.outfit(
                              fontSize: 11,
                              color: isDark ? AppTheme.darkText3 : AppTheme.text3)),
                      const Spacer(),
                      Text(
                        '$score / $total',
                        style: GoogleFonts.outfit(
                            fontSize: 14, fontWeight: FontWeight.w800, color: color),
                      ),
                      const SizedBox(width: 6),
                      Icon(Icons.chevron_right_rounded,
                          size: 16, color: isDark ? AppTheme.darkText4 : AppTheme.text4),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).animate(delay: Duration(milliseconds: index * 60))
        .fadeIn(duration: 350.ms)
        .slideX(begin: 0.05, end: 0);
  }
}

class _DetailBox extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final bool isDark;

  const _DetailBox(this.label, this.value, this.color, this.isDark);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Text(value, style: GoogleFonts.outfit(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
          const SizedBox(height: 2),
          Text(label, style: GoogleFonts.outfit(fontSize: 11, color: isDark ? AppTheme.darkText3 : AppTheme.text3)),
        ],
      ),
    );
  }
}

class _TimingRow extends StatelessWidget {
  final String label;
  final String value;
  final bool isDark;

  const _TimingRow(this.label, this.value, this.isDark);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: GoogleFonts.outfit(fontSize: 13, color: isDark ? AppTheme.darkText3 : AppTheme.text3)),
          Text(value, style: GoogleFonts.outfit(fontSize: 13, fontWeight: FontWeight.w600, color: isDark ? AppTheme.darkText1 : AppTheme.text1)),
        ],
      ),
    );
  }
}
